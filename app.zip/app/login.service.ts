
import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http:HttpClient,private _httpService: LoginService)  { }

  getUserDetails(username,password){
  	console.log(username);
  	console.log(password);
  	return this.http.get('http://localhost:8080/abc_bank/Customer/'+username+'/'+password);
  	
  }
}


