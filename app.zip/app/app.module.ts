import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutUsComponent } from './about-us/about-us.component';
//import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { d_LoginComponent } from './login/login.component';
import { d_CustomerComponent} from './d_customer/customer.component';
import { d_ProfileComponent } from './d_customer/profile/profile.component';
/*import { OwlModule } from 'ngx-owl-carousel';
import { BalanceComponent } from './d_customer/balance/balance.component';
import { FaqComponent } from './d_customer/faq/faq.component';
import { LoansComponent } from './d_customer/loans/loans.component';
import { MiniComponent } from './d_customer/mini/mini.component';
import { ProfileComponent } from './d_customer/profile/profile.component';
import { RequestLoanComponent } from './d_customer/request-loan/request-loan.component';
import { TermsComponent } from './d_customer/terms/terms.component';
import { TransferComponent } from './d_customer/transfer/transfer.component'; 
import { LoginService} from 'src/app/login.service';*/
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { MainpageComponent } from './mainpage/mainpage.component';

@NgModule({
  declarations: [
    AppComponent,
    AboutUsComponent,
    //HomeComponent,
    ContactComponent,
    d_LoginComponent,
    d_CustomerComponent,
    d_ProfileComponent,
    /*BalanceComponent,
    FaqComponent,
    LoansComponent,
    MiniComponent,
    ProfileComponent,
    RequestLoanComponent,
    TermsComponent,
    TransferComponent,*/
    MainpageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    //OwlModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
