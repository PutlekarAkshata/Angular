import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {AuthService} from 'src/app/auth.service';
import { ProfileService } from 'src/app/d_customer/profile/profile.service';
import {Customer} from 'src/app/d_customer/profile/Customer';
import {Customer_account} from 'src/app/d_customer/Customer_account';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class d_CustomerComponent implements OnInit {

  customerForm: FormGroup;
  submitted = false;
  bal=new Customer_account(0,'',0,'','','');

  constructor(private formBuilder: FormBuilder,private router: Router,private _httpService:ProfileService,public authService: AuthService) { }

  ngOnInit() {

    this.customerForm = this.formBuilder.group({
            balance: []
          });

    var balArray = new Array();
        this._httpService.getUserDetails().subscribe((res:any[])=>{
        var x=JSON.parse(JSON.stringify(res));
        console.log(x);
        for (var i = 0; i < x.length; i++) {
          balArray.push(x[i].balance);
        }
        this.bal.balance=x[0].balance;
         })
  }
profile()
{
	this.router.navigate(['d_profile'])
	
}
loans()
{
  this.router.navigate(['loans'])
}
transfer()
{
  this.router.navigate(['transfer'])
}
balance()
{
  this.router.navigate(['balance'])
}
mini()
{
  this.router.navigate(['mini'])
}
}
