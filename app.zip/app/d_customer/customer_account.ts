export class Customer_account{
	customer_Acc_no:number;
	open_date:string;
	balance:number;
	cust_id:string;
	account_id:string;
	approval:string;
	constructor(customer_Acc_no:number,open_date:string,balance:number,cust_id:string,account_id:string,approval:string)
	{
			this.customer_Acc_no=customer_Acc_no;
			this.open_date=open_date;
			this.balance=balance;
			this.cust_id=cust_id;
			this.account_id=account_id;
			this.approval=approval;
	}
}