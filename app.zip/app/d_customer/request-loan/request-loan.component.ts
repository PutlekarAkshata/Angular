import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-loan',
  templateUrl: './request-loan.component.html',
  styleUrls: ['./request-loan.component.css']
})
export class RequestLoanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
