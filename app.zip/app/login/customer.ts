export class Customer{
    cust_id:number;
	account_no:number;
	username:string;
	password:string;
	constructor(cust_id:number,account_no:number,username:string,password:string){
        this.cust_id=cust_id;
		this.account_no=account_no;
		this.username=username;
		this.password=password;
	}
}