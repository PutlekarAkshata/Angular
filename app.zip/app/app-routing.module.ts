import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { d_LoginComponent } from './login/login.component';
import { ContactComponent } from './contact/contact.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { d_ProfileComponent } from './d_customer/profile/profile.component';
import {d_CustomerComponent} from './d_customer/customer.component';

const routes: Routes = [
{path: '',redirectTo: 'mainpage',pathMatch:'full'},
{path: 'mainpage',component: MainpageComponent},
{path: 'd_login',component: d_LoginComponent},
{path: 'd_customer',component: d_CustomerComponent},
{path: 'd_profile',component: d_ProfileComponent}
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
